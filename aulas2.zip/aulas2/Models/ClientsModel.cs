namespace aulas.Models;

public class Client
{
    public int Id { get; set; }
    public string Nome {get; set; } = string.Empty;
    public string Emp {get; set; } = string.Empty;
    public string Mail { get; set; } = string.Empty;

}