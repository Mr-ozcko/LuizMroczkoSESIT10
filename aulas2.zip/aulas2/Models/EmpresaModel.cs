namespace aulas.Models;

public class Empresa
{
    public int Id { get; set; }
    public string Nome {get; set; } = string.Empty;
    public string End { get; set; } = string.Empty;
    public string Cat { get; set; } = string.Empty;

}

